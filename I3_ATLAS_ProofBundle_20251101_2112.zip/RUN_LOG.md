# 🧭 3I/ATLAS Photometric Analysis — Run Log Index
Author: Salah-Eddin Gherbi  
Repository: [GitHub](https://github.com/salahealer9/salah-gherbi-3I_ATLAS_Anomaly_2025)  
ORCID: [0009-0005-4017-1095](https://orcid.org/0009-0005-4017-1095)  

Each entry records an analysis session with associated files, hashes, and blockchain proofs.

| Date (UTC) | SHA256 of I3.txt | Proof Manifest | CSV | Timeline Plot | Color Summary |
|-------------|------------------|----------------|-----|----------------|----------------|
| 2025-10-31 18:27:38 UTC | `7e8bc1901f5943eaed6238c463afc5c6b700204a79b08a72391da7f67e5b9330` | I3_Color_Proof_20251031_1827.txt | I3_Color_Alerts_20251031_1827.csv | I3_Color_Brightness_Timeline_20251031_1827.png | Δ(g-o)=0.778, Δ(g-r)=0.506, Δ(r-o)=0.127 |
| 2025-10-31 18:33:02 UTC | `7e8bc1901f5943eaed6238c463afc5c6b700204a79b08a72391da7f67e5b9330` | I3_Color_Proof_20251031_1832.txt | I3_Color_Alerts_20251031_1832.csv | I3_Color_Brightness_Timeline_20251031_1832.png | Δ(g-o)=0.778, Δ(g-r)=0.506, Δ(r-o)=0.127 |
